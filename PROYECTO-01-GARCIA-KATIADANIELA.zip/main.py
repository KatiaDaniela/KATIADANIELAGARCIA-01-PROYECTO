import os
import sys
import getpass
 

from lifestore_file import lifestore_searches,lifestore_products,lifestore_sales
from usuarios import lista_usuarios
os.system("clear")
cve_usuario=input("proporciones el usuario  ")
if len(cve_usuario)==0:
  print ("DEBE PROPORCIONAR CLAVE DE USUARIO ")
  sys.exit(0)

band=False
nip=""
for usuario in lista_usuarios:
  if usuario[0]!= cve_usuario:
    continue
  band=True
  nip=usuario[1]
  break
if not band:
  print("No es clave de usuario válida en el sistema")
  sys.exit(0)
cve_nip=getpass.getpass("Indica tu contraseña ")
if(cve_nip != nip):
  print("la palabra clave proporcionada no coincide a la del usuario registrado")
  sys.exit(0)



#primer punto: Generar un listado de los 50 productos con mayores ventas 
os.system("clear")
frecuenciaVentaProductos=[]
for producto in lifestore_products:
  frecuenciaVentaProductos.append([producto[0],0,producto[1][0:40],producto[2]])
  # idproducto,ventas,nombreproducto,preio
for venta in lifestore_sales:
  if venta[4] !=0:
    continue
  idproducto=venta[1]
  unidades=1
  for frecuencia in frecuenciaVentaProductos:
    if frecuencia[0] != idproducto:
      
      continue
    frecuenciaVentaProductos.remove(frecuencia)
    frecuencia[1]=frecuencia[1]+unidades*frecuencia[3]
    frecuenciaVentaProductos.append(frecuencia)
    break

frecuenciaVentaProductosOrdenada=sorted(frecuenciaVentaProductos,key=lambda x:x[1])

print("****** 50 PRODUCTOS CON MAYOR VENTA *******")
print("_____________________________________________________________")
print("Producto\t\tNombre                               Impporte")
print("_____________________________________________________________")

for indice in range(1,51):
  op=-indice
  frecuencia=frecuenciaVentaProductosOrdenada[op]
  #print("\t"+str(frecuencia[0])+"  \t"+str(frecuencia[1]))
  print (f" {frecuencia[0]:6}\t {frecuencia[2]:40} \t{frecuencia[1]:8}")

# primer punto  100 productos con mayor búsquedas
frecuenciaBusquedasProductos=[]
for producto in lifestore_products:
  frecuenciaBusquedasProductos.append([producto[0],0,producto[1][0:40]])

for busqueda in lifestore_searches:
  idproducto=busqueda[1];
  
  for frecuencia in frecuenciaBusquedasProductos:
    if frecuencia[0] != idproducto:
      continue
    frecuenciaBusquedasProductos.remove(frecuencia)  
    frecuencia[1]=frecuencia[1]+1
    frecuenciaBusquedasProductos.append(frecuencia)
    break

ordenadabusqueda=sorted(frecuenciaBusquedasProductos,key=lambda x:x[1])
#print(ordenadabusqueda)
print()
print()
print()
print()
print("****** 100 PRODUCTOS CON MAYOR BÚSQUEDA *******")
print("_____________________________________________________________")
print("Producto\t\tNombre                               no.busquedas")
print("_____________________________________________________________")

limite=100;
if len(frecuenciaBusquedasProductos)<100:
  limite=len(ordenadabusqueda)
for indice in range(1,limite+1):
  op=-indice
  frecuencia=ordenadabusqueda[op]
  #print("\t"+str(frecuencia[0])+"  \t"+str(frecuencia[1]))
  print (f" {frecuencia[0]:6}\t {frecuencia[2]:40} \t{frecuencia[1]:8}")

# primer punto:Por categoría, generar un listado con los 50 productos con menores ventas

frecuenciaCategoriaProductos=[]
for producto in lifestore_products:
  frecuenciaCategoriaProductos.append([producto[0],0,producto[3],producto[1][0:40],producto[2] ])
for venta in lifestore_sales:
  if venta[4] !=0:
    continue
  idproducto=venta[1]
  unidades=1
  for frecuencia in frecuenciaCategoriaProductos:
    if frecuencia[0] != idproducto:
      continue
    frecuenciaCategoriaProductos.remove(frecuencia)
    frecuencia[1]=frecuencia[1]+unidades*frecuencia[4]
    frecuenciaCategoriaProductos.append(frecuencia)
    break

ordenadacategoria=sorted(frecuenciaCategoriaProductos,key=lambda x:(x[2],x[1]))
print()
print()
print()
print()

print("****** POR CATEGORÍA LOS 50 PRODUCTOS CON MENOR VENTA  *******")

print()

categoria=""
noproductos=0
for frecuencia in ordenadacategoria:
  if (frecuencia[2] != categoria):
    print("_________________________________________________________________")
    print ("Categoria : "+frecuencia[2])
    print("Producto\t\tNombre                                      Importe")
    print("_________________________________________________________________")
    categoria=frecuencia[2]
    noproductos=0
  noproductos=noproductos+1
  if(noproductos>50):
    continue
  print(f"{frecuencia[0]:8} \t {frecuencia[3]:40} \t {frecuencia[1]:8}")  

  #primer punto: Por categoría, los 100 productos con menores búsquedas.
frecuenciaCategoriaProductos=[]
for producto in lifestore_products:
  frecuenciaCategoriaProductos.append([producto[0],0,producto[3],producto[1][0:40]])
for busqueda in lifestore_searches:
  idproducto=busqueda[1]
  for frecuencia in frecuenciaCategoriaProductos:
    if frecuencia[0] != idproducto:
      continue
    frecuenciaCategoriaProductos.remove(frecuencia)
    frecuencia[1]=frecuencia[1]+unidades
    frecuenciaCategoriaProductos.append(frecuencia)
    break
ordenadacategoria=sorted(frecuenciaCategoriaProductos,key=lambda x:(x[2],x[1]))
print()
print()
print()
print()

print("****** POR CATEGORÍA LOS 100 PRODUCTOS CON MENOR búsqueda  *******")

print()

categoria=""
noproductos=0
for frecuencia in ordenadacategoria:
  if (frecuencia[2] != categoria):
    print("_________________________________________________________________")

    print ("Categoria : "+frecuencia[2])
    print("Producto\t\tNombre                                      busquedas")
    print("__________________________________________________________________")

    categoria=frecuencia[2]
    noproductos=0
  noproductos=noproductos+1
  if(noproductos>100):
    continue
  print(f"{frecuencia[0]:8} \t {frecuencia[3]:40} \t {frecuencia[1]:8}")  

#punto 2 :  un listado para LOS 20 productos con las mejores reseñas considerando devoluciones
frecuenciaResenasProductos=[]
for producto in lifestore_products:
  frecuenciaResenasProductos.append([producto[0],0,0,0,producto[1][0:40]])
  #0=suma de puntos de reseñas, total de reseñas, promedio de reseñas
for venta in lifestore_sales:
  idproducto=venta[1]
  puntosreseña=venta[2]
  for frecuencia in frecuenciaResenasProductos:
    if frecuencia[0] != idproducto:
      continue
    frecuenciaResenasProductos.remove(frecuencia)
    frecuencia[1]=frecuencia[1]+puntosreseña
    frecuencia[2]=frecuencia[2]+1
    frecuencia[3]=frecuencia[1]/frecuencia[2]
    frecuenciaResenasProductos.append(frecuencia)
    break
  ordenadaresena=sorted(frecuenciaResenasProductos,key=lambda x:x[3])
#print(ordenadabusqueda)
print()
print()
print()
print()
print("****** 20 PRODUCTOS CON LAS MEJORES RESEÑAS *******")
print("________________________________________________________________")
print("Producto\t\tNombre                            promedio reseñas")
print("_________________________________________________________________")

#print(frecuenciaResenasProductos)
for indice in range(1,21):
  indice=-indice
  resena=frecuenciaResenasProductos[indice]
  print(f"{resena[0]:8} \t {resena[4]:40} \t {resena[3]:8.2f}")  

  #punto 2 :  un listado para productos con las peores reseñas considerando devoluciones
print()
print()
print()
print()
print("****** 20 PRODUCTOS CON LAS PEORES RESEÑAS *******")
print("________________________________________________________________")
print("Producto\t\tNombre                            promedio reseñas")
print("_________________________________________________________________")

#print(frecuenciaResenasProductos)
for indice in range(0,20):
  resena=frecuenciaResenasProductos[indice]
  print(f"{resena[0]:8} \t {resena[4]:40} \t {resena[3]:8.2f}")

#punto no. 3:
frecuenciaVentasMes=[]

frecuenciaVentasMes.append([0,0,0,0,0,0,0,0,0,0,0,0])
listaMeses=[]
listaMeses.append(    [  [1,"Enero"],[2,"Febrero"],[3,"Marzo"],[4,"Abril"],
 [5,"Mayo"],[6,"Junio"],[7,"Julio"],[8,"Agosto"],
  [9,"Septiembre"],[10,"Octubre"],[11,"Noviembre"],[12,"Diciembre"]

   ] )


# los ceros representan las ventas de los doce meses
acumuladoAnual=0
for venta in lifestore_sales:
  mes= int(venta[3][3:5])
  idproducto=venta[1]  
  for producto in lifestore_products:
    if idproducto != producto[0]:
      continue
    frecuenciaVentasMes[0][mes-1]=frecuenciaVentasMes[0][mes-1]+producto[2]
    acumuladoAnual=acumuladoAnual+producto[2]
    break

print()
print()
print()
print()
print("************** TOTAL ANUAL E INGREOS PROMEDIO POR MES **************")
print("                    IMPORTE ANUAL $ "+str(acumuladoAnual))
print("   No.      Mes                                          Importe")

nombreMeses=listaMeses[0]
for nomMes in nombreMeses:
 
  mes=nomMes[0]

  print(f"  {nomMes[0]:4}      {nomMes[1]:30}           {frecuenciaVentasMes[0][mes-1]:10.2f}") 

# punto 3, segundo reporte
mayor=0
for i in range(0,12):
   if frecuenciaVentasMes[0][i]>mayor:
     mayor=frecuenciaVentasMes[0][i]

print()
print()
print()
print()
print("************** MESES CON MÁS VENTAS EN EL AÑO  **************")
print("                    IMPORTE MENSUAL MAYOR $ "+str(mayor))
print("   No.      Mes              ")

for i in range(0,12):
   if frecuenciaVentasMes[0][i]==mayor:
     print(f"{i:8}   {listaMeses[0][i][1]:30}")

